title: PHP的开始
date: '2019-08-19 16:53:24'
updated: '2019-08-19 16:54:17'
tags: [PHP]
permalink: /articles/2019/08/19/1566204804798.html
---
![](https://img.hacpai.com/bing/20180909.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

我相信大多数的程序员的第一段代码都是及其熟悉的 Hello,Word,而在php里面,他是这样编写的
```
<?php
	echo "Hello,Word";
?>
```
而这,也就是PHP的开始
